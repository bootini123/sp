# -*- coding: utf-8 -*-

import logging

import logging.handlers

import os

class logManager():
    def __init__(self,name,file_name='runnerSpider.log'):
        self.name = name

        # create logs file folder
        logs_dir = os.path.join(os.path.curdir, "logs")
        if os.path.exists(logs_dir) and os.path.isdir(logs_dir):
            pass
        else:
            os.mkdir(logs_dir)

        # set initial log level
        self.logger = logging.getLogger(self.name)
        self.logger.setLevel(logging.INFO)

        # define a rotating file handler
        rotatingFileHandler = logging.handlers.RotatingFileHandler(filename='./logs/'+file_name,

                                                               maxBytes=1024 * 1024 * 50,

                                                               backupCount=5)

        formatter = logging.Formatter("%(asctime)s - %(levelname)s [%(name)s] %(message)s ")

        rotatingFileHandler.setFormatter(formatter)

        self.logger.addHandler(rotatingFileHandler)

        # define a handler whitch writes messages to sys

        console = logging.StreamHandler()

        console.setLevel(logging.INFO)

        # set a format which is simple for console use

        # formatter = logging.Formatter("%(name)-12s: %(levelname)-8s %(message)s")

        # tell the handler to use this format

        console.setFormatter(formatter)

        # add the handler to the root logger

        self.logger.addHandler(console)



    def info(self, msg):
        self.logger.info(msg)

    def warning(self, msg):
        self.logger.warning(msg)

    def error(self, msg):
        self.logger.error(msg)

    def debug(self, msg):
        self.logger.debug(msg)



