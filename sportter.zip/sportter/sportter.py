# -*- coding: utf-8 -*-
import requests
import json,os,time
from datetime import datetime
import threading
from log_mgr import logManager
from cache_mgr import cacheMgr

def getJSON(mid,type="machInfo"):
    mid = str(mid)
    url = ""
    if type == 'machInfo':
        url = "https://i.sporttery.cn/api/fb_match_info/get_match_info?mid="+mid+"&f_callback=getMatchInfo"
    elif type == "poolPrcess":
        url = "https://i.sporttery.cn/api/fb_match_info/get_pool_rs/?f_callback=pool_prcess&mid=" + mid
    else:
        return
    headers = {
        'accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        'accept-encoding': "gzip, deflate, br",
        'accept-language': "zh-CN,zh;q=0.9",
        'cache-control': "max-age=0",
        'connection': "keep-alive",
        'host': "i.sporttery.cn",
        'upgrade-insecure-requests': "1",
        'User - Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'
    }
    try:
        response = requests.request("GET", url, headers=headers)
        content = response.text
    except Exception as e:
        logger.error("ERROR mid : " + str(mid) + " " + str(e))
    return content

def getMach(mid,cacheManager):
    logger.info("Spider match : " + str(mid))
    machInfo = getJSON(mid, type="machInfo")
    if len(machInfo) > 20:
        try:
            infoJSON = json.loads(machInfo.split("(")[1].split(")")[0])
        except  Exception as e:
            logger.error("ERROR mid : " + str(mid) + " " + str(e))
    else:
        return
    infoRes = infoJSON['result']
    id = infoRes['match_id']
    matchDate = infoRes['date_cn']
    matchTime = infoRes['time_cn']
    matchLocal = infoRes['h_cn']
    matchGuest = infoRes['a_cn']
    matchLevel = infoRes['l_cn']

    poolInfo = getJSON(mid, type="poolPrcess")
    if len(machInfo) > 20:
        poolJSON = json.loads(poolInfo.split("(")[1].split(")")[0])
    else:
        return
    if 'result' in poolJSON:
        poolRes = poolJSON['result']
    else:
        logger.error("ERROR mid : " + str(mid) )
        return

    ttg= poolRes['pool_rs']['ttg']['prs_name']
    odds = poolRes['odds_list']['ttg']['odds'][0]
    s0 = odds['s0']
    s1 = odds['s1']
    s2 = odds['s2']
    s3 = odds['s3']
    s4 = odds['s4']
    s5 = odds['s5']
    s6 = odds['s6']
    s7 = odds['s7']
    cacheManager.add_cache(mid,[mid,id , matchDate, matchTime, matchLevel, matchLocal, matchGuest , ttg, s0, s1, s2, s3, s4, s5, s6, s7])

# 最大线程数MAX_THREADS；睡眠时间DELAY
def run(mids,cacheManager,MAX_THREADS = 30,DELAY = 1):
    for mid in mids:
        while len(threads) >= MAX_THREADS:
            for t in threads:
                if not t.is_alive():
                    threads.remove(t)
            time.sleep(DELAY)
        t = threading.Thread(target=getMach, name=None, args=(mid,cacheManager,))
        t.setDaemon(False) #False等待所有线程结束，True不等待
        t.start()
        threads.append(t)

if __name__ == '__main__':
    start_time = datetime.now()
    threads = []
    logger = logManager(os.path.basename(__file__).split(".")[0],file_name="matchSipder.log")
    logger.info("Start spider match info ...")
    CACHE_SIZE = 10
    cm = cacheMgr(CACHE_SIZE)
    # 指定mid范围range(120000,120101)
    run(range(120000,120101),cm,MAX_THREADS=30)
    # 检验所有线程都已经跑完则执行最后一次清场cache
    while True:
        for t in threads:
            time.sleep(1)
            if t.is_alive():
                continue
            else:
                time.sleep(2)
                for t in threads:
                    if t.is_alive():
                        continue
        cm.pop_cache()
        break

    logger.info("Cost time : %d seconds" % (datetime.now() - start_time).seconds)


