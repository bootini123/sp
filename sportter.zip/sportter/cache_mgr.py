# -*- coding: utf-8 -*-

import time
import threading
from log_mgr import logManager
import os

class cacheMgr:
    def __init__(self,MAX_CACHE=10,FILE_NAME="res.csv"):
        self._cache = {}
        self._file_name = FILE_NAME
        self._lock = threading.Lock()
        self.max_cache = MAX_CACHE
        self.logger = logManager(os.path.basename(__file__).split(".")[0],file_name="matchSipder.log")

    def chk_cache(self):
        if len(self._cache) % self.max_cache == 0 and len(self._cache) != 0 :
            self.logger.info("Pop " + str(self.max_cache) + " cache write to disk")
            # 引用类型需要加copy，而不是地址引用
            temp_cache = self._cache.copy()
            self._cache.clear()
            self.pop_cache(temp_cache)

    def pop_cache(self,cache_set=None):
        # 如果为空则是清空所有cache，用于最后一轮
        if cache_set is  None:
            self.logger.info("Pop all cache for stopping, clear "+str(len(self._cache))+" cache")
            if len(self._cache) != 0:
                temp_cache = self._cache.copy()
                self._cache.clear()
                self.save_disk(temp_cache)
        else:
            self.save_disk(cache_set)

    def save_disk(self,cache_set):
        res = ""
        for key, value in cache_set.items():
            for v in value:
                res = res + str(v) + ","
            res += "\n"

        with open(self._file_name, 'a') as f:
            f.write(res)
            # print(str(value))

    def add_cache(self,key,value):
        with self._lock:
            self._cache[key] = value
            self.chk_cache()








